g++ -std=c++17 test_led.cpp LEDController.cpp -o test_led -lpthread -lgpiodcxx -lgpiod
